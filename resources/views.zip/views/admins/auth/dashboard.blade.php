@extends('layouts.adminApp')
@section('content')
    <div>home</div>
    
@endsection