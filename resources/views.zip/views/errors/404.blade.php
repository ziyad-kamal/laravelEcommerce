@extends('layouts.app')

@section('content')
    <h1 class="text-center">
        page not found 
        <a href="{{url('items/get')}}" class="btn btn-primary">go to items page</a>
    </h1>
    
@endsection